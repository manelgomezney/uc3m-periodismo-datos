En esta carpeta se guardarán todas las imágenes
