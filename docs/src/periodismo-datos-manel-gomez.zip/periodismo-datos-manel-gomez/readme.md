Repositorio de Manel Gómez Ney, Grupo 61, para la asignatura de Periodismo de datos
